
const $ = (q,el=document)=>el.querySelector(q); let map, routeLine;
function initMap(){ map = L.map('map').setView([48.4,10.0], 9);
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'&copy; OpenStreetMap'}).addTo(map); }
async function geocode(q){ const res = await fetch('https://nominatim.openstreetmap.org/search?format=json&q='+encodeURIComponent(q));
  const d = await res.json(); if(!d.length) throw new Error('not found'); return [parseFloat(d[0].lat), parseFloat(d[0].lon)]; }
async function route(a,b){ const url = `https://router.project-osrm.org/route/v1/driving/${a[1]},${a[0]};${b[1]},${b[0]}?overview=full&geometries=geojson`;
  const r = await (await fetch(url)).json(); const R = r.routes?.[0]; if(!R) throw new Error('route fail');
  const km=R.distance/1000, min=R.duration/60; const coords=R.geometry.coordinates.map(([x,y])=>[y,x]);
  if(routeLine) map.removeLayer(routeLine); routeLine=L.polyline(coords,{color:'#FFD700',weight:5}).addTo(map); map.fitBounds(routeLine.getBounds(),{padding:[30,30]}); return {km,min}; }
function calc(km,min){ let base=4, perKm=1.6, perMin=0.25; const t=$('#tariff').value; if(t==='night'){base=5;perKm=1.85;perMin=0.30} if(t==='express'){base=6;perKm=2.1;perMin=0.35}
  const pax=Math.max(1,parseInt($('#pax').value||'1',10)); const price=(base+km*perKm+min*perMin)*(pax>4?1.15:1.0); return Math.max(6,Math.round(price*100)/100); }
async function compute(){ $('#go').disabled=true; try{ const a=await geocode($('#from').value); const b=await geocode($('#to').value); const {km,min}=await route(a,b); const price=calc(km,min);
  $('#km').textContent=km.toFixed(1)+' km'; $('#min').textContent=Math.round(min)+' min'; $('#fare').textContent=price.toFixed(2)+' €';
  const msg=encodeURIComponent(`ZENTY EXPRESS – Talep\nFrom: ${$('#from').value} → To: ${$('#to').value}\nKm: ${km.toFixed(1)} • Min: ${Math.round(min)}\nTarife: ${$('#tariff').value} • Kişi: ${$('#pax').value}`);
  $('#wa').href='https://wa.me/491625757957?text='+msg; $('#tg').href='https://t.me/ZentyExpressBot?start=angebot'; }catch(e){ alert('Rota bulunamadı'); } $('#go').disabled=false; }
window.addEventListener('DOMContentLoaded', initMap);
